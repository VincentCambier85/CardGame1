public class Cartes {
    private String valeur;
    private String couleur;

    public Cartes(String valeur, String couleur) {
        this.valeur = valeur;
        this.couleur = couleur;
    }

    public String toString() {
        return valeur + " de " + couleur;
    }
}
