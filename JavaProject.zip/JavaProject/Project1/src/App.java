public class App {
    public static void main(String[] args) throws Exception {
        
        // System.out.println("Hello, World!");

        String[] valeurs = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "Valet", "Reine", "Roi", "As"};
        String[] couleurs = {"Carreau", "Coeur", "Pique", "Trèfle"};

        Cartes[] jeuDeCartes = new Cartes[52];
        int index = 0;

        // Initialisation du jeu de cartes
        for (String couleur : couleurs) {
            for (String valeur : valeurs) {
                jeuDeCartes[index] = new Cartes(valeur, couleur);
                index++;
            }
        }

        // Affichage des cartes dans la console
        for (int i = 0; i < jeuDeCartes.length; i++) {
            System.out.println(jeuDeCartes[i]);
            
            // Ajout d'un saut de ligne après chaque série de cartes d'une même couleur
            if ((i + 1) % valeurs.length == 0) {
                System.out.println();
            }
        }
    }
}